def print_lol(content):
    """" I am Test"""
    print('test')